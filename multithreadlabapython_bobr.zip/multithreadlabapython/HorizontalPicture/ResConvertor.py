import os
from pathlib import Path
from threading import Thread
import cProfile
import pstats
from PIL import Image

cwd = os.getcwd()
cwdObject = Path(cwd)
pathFolderRead = cwdObject / "images"
pathFolderWrite = cwdObject / "complete"

# files = glob.glob(path)


def EditImage(pathFile):
    print(cwd + pathFile)
    with Image.open(pathFolderRead / pathFile) as img:
        if img.width == 1080 and img.height == 1080:
            # Вырезаем из исходника который с метталекса картину
            img = img.crop((120, 0, img.width - 120, img.height))
        try:
            os.makedirs(pathFolderWrite / pathFile)
        except FileExistsError:
            print("Folder exist", i)
        new = img.resize((805, 601))
        new.save(pathFolderWrite / pathFile / "ORIGINDONTTOUCH.jpg")

        new = img.resize((695, 627))
        infoback = Image.open("infoback.png")
        infoback.paste(new, (0, 127))
        infoback.save(pathFolderWrite / pathFile / "2.jpg")

        new = img.resize((899, 699))
        interier = Image.open("interer.jpg")
        interier.paste(new, (150, 30))
        interier.save(pathFolderWrite / pathFile / "3.jpg")

        new = img.resize((735, 445))
        background = Image.open("background.png")
        background.paste(new, (90, 355))
        background.save(pathFolderWrite / pathFile / "1.jpg")
        sizes = Image.open("sizes.png").convert("RGBA")
        background.paste(sizes, mask=sizes)
        background.save(pathFolderWrite / pathFile / "4.jpg")


locdir = pathFolderRead
listFiles = os.listdir(locdir)
i = 1
choiseMultithreadMode = True
choiseRaw = input("please enter y or n for select multithread mode\n\r")
choiseMultithreadMode = bool(choiseRaw == "y" or choiseRaw == "Y")
print("Selected value " + "Y" if choiseMultithreadMode else "N")
files_threads: list[Thread] = []
with cProfile.Profile() as profiler:
    for file in listFiles:
        if file.endswith((".jpg", ".png")):
            if choiseMultithreadMode:
                args = [file]
                thread = Thread(target=EditImage, args=args)
                thread.start()
                files_threads.append(thread)
            else:
                EditImage(file)

    for file_thread in files_threads:
        file_thread.join()
stats = pstats.Stats(profiler)
stats.sort_stats(pstats.SortKey.CUMULATIVE)
stats.print_stats(15)
