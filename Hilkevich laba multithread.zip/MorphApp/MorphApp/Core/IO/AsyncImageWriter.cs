﻿using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;

namespace MorphApp.Core.IO
{
    public static class AsyncImageWriter
    {
        public static async Task WriteAsync(string filePath, byte[] pixels, int width, int height, CancellationToken token)
        {
            // 1. Собираем Bitmap из массива байт
            byte[] pngBytes = await Task.Run(() =>
            {
                token.ThrowIfCancellationRequested();

                using var bitmap = new Bitmap(width, height, PixelFormat.Format32bppArgb);
                BitmapData bmpData = bitmap.LockBits(
                    new Rectangle(0, 0, width, height),
                    ImageLockMode.WriteOnly,
                    PixelFormat.Format32bppArgb);

                try
                {
                    Marshal.Copy(pixels, 0, bmpData.Scan0, pixels.Length);
                }
                finally
                {
                    bitmap.UnlockBits(bmpData);
                }

                using var ms = new MemoryStream();
                bitmap.Save(ms, ImageFormat.Png);
                return ms.ToArray();
            }, token);

            // 2. Асинхронно пишем файл на диск
            await File.WriteAllBytesAsync(filePath, pngBytes, token);
        }
    }
}