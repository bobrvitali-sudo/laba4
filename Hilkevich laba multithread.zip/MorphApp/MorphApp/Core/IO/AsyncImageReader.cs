﻿using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;

namespace MorphApp.Core.IO
{
    public static class AsyncImageReader
    {
        public static async Task<(byte[] pixels, int width, int height)> ReadAsync(string filePath, CancellationToken token)
        {
            // 1. Асинхронно читаем файл в память (не блокируем UI)
            byte[] fileBytes = await File.ReadAllBytesAsync(filePath, token);

            // 2. Декодируем изображение из памяти в Bitmap
            return await Task.Run(() =>
            {
                token.ThrowIfCancellationRequested();

                using var ms = new MemoryStream(fileBytes);
                using var originalBitmap = new Bitmap(ms);

                // Создаем Bitmap в формате 32bppArgb (4 байта на пиксель)
                using var formattedBitmap = new Bitmap(originalBitmap.Width, originalBitmap.Height, PixelFormat.Format32bppArgb);
                using (var g = Graphics.FromImage(formattedBitmap))
                {
                    g.DrawImage(originalBitmap, 0, 0, originalBitmap.Width, originalBitmap.Height);
                }

                int width = formattedBitmap.Width;
                int height = formattedBitmap.Height;
                byte[] pixels = new byte[width * height * 4];

                BitmapData bmpData = formattedBitmap.LockBits(
                    new Rectangle(0, 0, width, height),
                    ImageLockMode.ReadOnly,
                    PixelFormat.Format32bppArgb);

                try
                {
                    IntPtr ptr = bmpData.Scan0;
                    Marshal.Copy(ptr, pixels, 0, pixels.Length);
                }
                finally
                {
                    formattedBitmap.UnlockBits(bmpData);
                }

                return (pixels, width, height);
            }, token);
        }
    }
}