﻿using MorphApp.Models;

namespace MorphApp.Core.Processing
{
    public static class ImageProcessor
    {
        public static TileResult ProcessTile(Tile tile, CancellationToken token)
        {
            token.ThrowIfCancellationRequested();
            var sw = System.Diagnostics.Stopwatch.StartNew();

            int width = tile.InputWidth;
            int height = tile.InputHeight;
            byte[] input = tile.InputPixels;

            // 1. Бинаризация (порог 128)
            byte[] binary = new byte[input.Length];
            for (int i = 0; i < input.Length; i += 4)
            {
                byte b = input[i];
                byte g = input[i + 1];
                byte r = input[i + 2];
                byte a = input[i + 3];

                // Формула яркости
                int gray = (int)(0.299 * r + 0.587 * g + 0.114 * b);
                byte val = gray > 128 ? (byte)255 : (byte)0;

                binary[i] = val;     // B
                binary[i + 1] = val; // G
                binary[i + 2] = val; // R
                binary[i + 3] = a;   // Alpha
            }

            // 2. Морфология (Эрозия, затем Дилатация) - ядро 3х3
            byte[] eroded = ApplyMorphology(binary, width, height, isErosion: true, token);
            byte[] dilated = ApplyMorphology(eroded, width, height, isErosion: false, token);

            sw.Stop();

            return new TileResult
            {
                TileIndex = tile.Index,
                OutputPixels = dilated,
                ProcessingTimeMs = sw.ElapsedMilliseconds
            };
        }

        // Вспомогательный метод для Эрозии и Дилатации
        private static byte[] ApplyMorphology(byte[] src, int width, int height, bool isErosion, CancellationToken token)
        {
            byte[] dst = new byte[src.Length];
            int offset = 1; // Смещение для 3х3 (берем пиксель слева/справа/сверху/снизу)

            for (int y = 1; y < height - 1; y++)
            {
                token.ThrowIfCancellationRequested();
                for (int x = 1; x < width - 1; x++)
                {
                    bool isWhite = isErosion; // Для эрозии ищем минимум (если все белые), для дилатации - максимум

                    // Проходим по окрестности 3х3 (только по одному каналу, т.к. картинка ч/б)
                    for (int dy = -1; dy <= 1; dy++)
                    {
                        for (int dx = -1; dx <= 1; dx++)
                        {
                            int nx = x + dx;
                            int ny = y + dy;
                            int srcIdx = (ny * width + nx) * 4;
                            bool pixelIsWhite = src[srcIdx] == 255;

                            if (isErosion && !pixelIsWhite) { isWhite = false; break; }
                            if (!isErosion && pixelIsWhite) { isWhite = true; break; }
                        }
                        if (isErosion && !isWhite) break;
                        if (!isErosion && isWhite) break;
                    }

                    int idx = (y * width + x) * 4;
                    byte val = isWhite ? (byte)255 : (byte)0;
                    dst[idx] = val;       // B
                    dst[idx + 1] = val;   // G
                    dst[idx + 2] = val;   // R
                    dst[idx + 3] = src[idx + 3]; // Alpha
                }
            }

            // Копируем края (1 пиксель рамки) без изменений
            for (int x = 0; x < width; x++)
            {
                int topIdx = x * 4;
                int botIdx = ((height - 1) * width + x) * 4;
                Array.Copy(src, topIdx, dst, topIdx, 4);
                Array.Copy(src, botIdx, dst, botIdx, 4);
            }
            for (int y = 0; y < height; y++)
            {
                int leftIdx = (y * width) * 4;
                int rightIdx = (y * width + width - 1) * 4;
                Array.Copy(src, leftIdx, dst, leftIdx, 4);
                Array.Copy(src, rightIdx, dst, rightIdx, 4);
            }

            return dst;
        }
    }
}