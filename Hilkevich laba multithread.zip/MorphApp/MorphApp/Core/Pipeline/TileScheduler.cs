﻿using MorphApp.Models;

namespace MorphApp.Core.Pipeline
{
    public static class TileScheduler
    {
        // Делит изображение на горизонтальные полосы (тайлы) с нахлестом в 1 пиксель
        public static List<Tile> CreateTiles(byte[] sourcePixels, int width, int height, int tileHeight = 100)
        {
            var tiles = new List<Tile>();
            int tileIndex = 0;

            for (int y = 0; y < height; y += tileHeight)
            {
                int startY = y;
                int endY = Math.Min(y + tileHeight, height); // Чистая высота (без нахлеста)

                // Вычисляем с нахлестом (для 3х3 ядра нужно по 1 пикселю сверху и снизу)
                int overlapStartY = Math.Max(0, startY - 1);
                int overlapEndY = Math.Min(height, endY + 1);
                int overlapHeight = overlapEndY - overlapStartY;

                // Вырезаем пиксели для этого тайла (включая нахлест)
                byte[] tilePixels = new byte[width * overlapHeight * 4];
                int sourceOffset = (overlapStartY * width) * 4;
                Array.Copy(sourcePixels, sourceOffset, tilePixels, 0, tilePixels.Length);

                tiles.Add(new Tile
                {
                    Index = tileIndex++,
                    StartY = startY,
                    EndY = endY,
                    InputPixels = tilePixels,
                    InputWidth = width,
                    InputHeight = overlapHeight,
                    OriginalHeight = endY - startY,
                    OffsetY = startY - overlapStartY // 1, если есть нахлест сверху, иначе 0
                });
            }

            return tiles;
        }
    }
}