﻿using MorphApp.Core.Processing;
using MorphApp.Models;

namespace MorphApp.Core.Pipeline
{
    public class ThreadPoolManager
    {
        private readonly int _maxThreads;
        private readonly ResultCollector _collector;
        private readonly List<Tile> _queue = new List<Tile>();

        // Механизмы синхронизации (События и блокировки)
        private readonly object _lockQueue = new object();       // Крит. секция для очереди
        private readonly AutoResetEvent _jobAvailable = new AutoResetEvent(false); // Сигнал "есть работа"
        private readonly CountdownEvent _allDone;                // Счетчик завершения

        private readonly CancellationTokenSource _cts;
        private int _activeThreads = 0;
        private readonly object _lockProgress = new object();

        public event Action<int>? OnProgressChanged; // Событие для UI

        public ThreadPoolManager(int threadsCount, int totalTiles, ResultCollector collector, CancellationTokenSource cts)
        {
            _maxThreads = threadsCount;
            _collector = collector;
            _cts = cts;
            _allDone = new CountdownEvent(totalTiles);
        }

        public void Start(List<Tile> tiles)
        {
            // Создаем фиксированное количество потоков
            for (int i = 0; i < _maxThreads; i++)
            {
                var thread = new Thread(WorkerLoop) { IsBackground = true };
                thread.Start();
            }

            // Загружаем задания в очередь
            lock (_lockQueue)
            {
                _queue.AddRange(tiles);
                _jobAvailable.Set(); // Сигнализируем, что появились задачи
            }
        }

        private void WorkerLoop()
        {
            while (!_cts.IsCancellationRequested)
            {
                Tile? tileToProcess = null;

                // КРИТИЧЕСКАЯ СЕКЦИЯ: Берем задачу из очереди
                lock (_lockQueue)
                {
                    if (_queue.Count > 0)
                    {
                        tileToProcess = _queue[0];
                        _queue.RemoveAt(0);
                    }
                }

                if (tileToProcess == null)
                {
                    // Если очередь пуста и все потоки свободны — выходим
                    lock (_lockProgress)
                    {
                        _activeThreads--;
                        if (_activeThreads == 0) return; // Больше работы нет
                    }

                    // Ждем появления новой работы (событие)
                    _jobAvailable.WaitOne(100);
                    lock (_lockProgress) { _activeThreads++; }
                    continue;
                }

                try
                {
                    // Обработка тайла
                    var result = ImageProcessor.ProcessTile(tileToProcess, _cts.Token);

                    // СБОРКА: Критическая секция внутри сборщика
                    _collector.Collect(result, tileToProcess.StartY, tileToProcess.OriginalHeight, tileToProcess.OffsetY);

                    // Сигнализируем о прогрессе
                    OnProgressChanged?.Invoke(_collector.CompletedTilesCount);

                    // Отмечаем задачу как выполненную
                    _allDone.Signal();
                }
                catch (OperationCanceledException)
                {
                    break; // Отмена
                }
            }
        }

        // Ждем, пока все потоки завершат работу
        public void WaitForCompletion()
        {
            _allDone.Wait();
        }
    }
}