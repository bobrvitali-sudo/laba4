﻿using MorphApp.Models;

namespace MorphApp.Core.Pipeline
{
    public class ResultCollector
    {
        public byte[] FinalPixels { get; }
        private readonly int _width;
        private readonly object _lockObj = new object(); // Критическая секция

        public int CompletedTilesCount { get; private set; }

        public ResultCollector(int width, int height)
        {
            _width = width;
            FinalPixels = new byte[width * height * 4];
        }

        public void Collect(TileResult result, int startY, int originalHeight, int offsetY)
        {
            lock (_lockObj) // Защищаем общие данные
            {
                // Вычисляем, откуда брать чистые пиксели (пропускаем нахлест)
                int sourceOffset = (offsetY * _width) * 4;
                int destOffset = (startY * _width) * 4;
                int bytesToCopy = originalHeight * _width * 4;

                Array.Copy(result.OutputPixels, sourceOffset, FinalPixels, destOffset, bytesToCopy);

                CompletedTilesCount++;
            }
        }
    }
}