﻿namespace MorphApp.Models
{
    public class ProgressState
    {
        public int ProcessedTiles { get; set; }
        public int TotalTiles { get; set; }
        public double Percentage => TotalTiles == 0 ? 0 : (double)ProcessedTiles / TotalTiles * 100;
    }
}