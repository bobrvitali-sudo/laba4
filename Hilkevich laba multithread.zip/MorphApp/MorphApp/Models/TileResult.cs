﻿namespace MorphApp.Models
{
    public class TileResult
    {
        public int TileIndex { get; set; }
        public byte[] OutputPixels { get; set; } = Array.Empty<byte>(); // Пиксели без перекрытия (чистые)
        public long ProcessingTimeMs { get; set; } // Для замеров времени в отчете
    }
}