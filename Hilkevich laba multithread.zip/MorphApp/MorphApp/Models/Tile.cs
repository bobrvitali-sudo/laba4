﻿namespace MorphApp.Models
{
    public class Tile
    {
        public int Index { get; set; } // Порядковый номер тайла (сверху вниз)
        public int StartY { get; set; } // Начальная строка чистой области (включительно)
        public int EndY { get; set; }   // Конечная строка чистой области (не включительно)

        // Входные данные (с перекрытием для морфологии)
        public byte[] InputPixels { get; set; } = Array.Empty<byte>();
        public int InputWidth { get; set; }
        public int InputHeight { get; set; } // Высота с учетом перекрытия (1 сверху и 1 снизу)

        // Размеры оригинального (чистого) тайла
        public int OriginalHeight { get; set; }
        public int OffsetY { get; set; } // Смещение чистой области внутри InputPixels
    }
}