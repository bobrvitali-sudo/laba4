using MorphApp.Forms; 

namespace MorphApp
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            ApplicationConfiguration.Initialize();
            Application.Run(new MainForm()); 
        }
    }
}