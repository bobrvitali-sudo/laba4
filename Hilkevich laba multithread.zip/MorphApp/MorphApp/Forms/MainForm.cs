using MorphApp.Core.IO;
using MorphApp.Core.Pipeline;
using MorphApp.Core.Processing;
using System.Drawing;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MorphApp.Forms
{
    public partial class MainForm : Form
    {
        private byte[]? _sourcePixels;
        private int _imageWidth;
        private int _imageHeight;
        private CancellationTokenSource? _cts;
        private byte[]? _resultPixels; // Здесь храним финальную картинку

        public MainForm()
        {
            InitializeComponent();
        }

        private async void btnOpen_Click(object sender, EventArgs e)
        {
            using var ofd = new OpenFileDialog();
            ofd.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp";

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    txtLog.AppendText($"Чтение {ofd.FileName}...\r\n");
                    btnOpen.Enabled = false;

                    var result = await AsyncImageReader.ReadAsync(ofd.FileName, CancellationToken.None);
                    _sourcePixels = result.pixels;
                    _imageWidth = result.width;
                    _imageHeight = result.height;

                    picOriginal.Image?.Dispose();
                    picOriginal.Image = new Bitmap(ofd.FileName);
                    txtLog.AppendText($"Загружено: {_imageWidth}x{_imageHeight}\r\n");
                    btnProcess.Enabled = true;
                    btnSave.Enabled = false; // Сбрасываем кнопку сохранения при новой загрузке
                }
                catch (Exception ex) { MessageBox.Show("Ошибка: " + ex.Message); }
                finally { btnOpen.Enabled = true; }
            }
        }

        private void btnProcess_Click(object sender, EventArgs e)
        {
            if (_sourcePixels == null) return;

            btnProcess.Enabled = false;
            btnCancel.Enabled = true;
            btnSave.Enabled = false;
            progressBar.Value = 0;
            txtLog.AppendText("--- Многопоточная обработка ---\r\n");

            _cts = new CancellationTokenSource();

            // Замеряем общее время
            var swTotal = System.Diagnostics.Stopwatch.StartNew();

            var tiles = TileScheduler.CreateTiles(_sourcePixels, _imageWidth, _imageHeight, 100);
            var collector = new ResultCollector(_imageWidth, _imageHeight);

            // Создаем пул на 4 потока (для замеров можно поставить 1, 2, 4, 8)
            var pool = new ThreadPoolManager(8, tiles.Count, collector, _cts);

            pool.OnProgressChanged += (processedCount) =>
            {
                this.Invoke((MethodInvoker)delegate
                {
                    progressBar.Value = (int)((double)processedCount / tiles.Count * 100);
                });
            };

            Task.Run(() =>
            {
                pool.Start(tiles);
                pool.WaitForCompletion();
            }).ContinueWith(t =>
            {
                swTotal.Stop(); // Останавливаем таймер

                this.Invoke((MethodInvoker)delegate
                {
                    if (_cts.IsCancellationRequested)
                    {
                        txtLog.AppendText("ОБРАБОТКА ОТМЕНЕНА.\r\n");
                    }
                    else
                    {
                        txtLog.AppendText($"Успешно завершено за {swTotal.ElapsedMilliseconds} мс!\r\n");
                        _resultPixels = collector.FinalPixels; // Сохраняем финальный массив

                        // Выводим на экран
                        picOriginal.Image?.Dispose();
                        using (var ms = new MemoryStream())
                        {
                            using (var bmp = new Bitmap(_imageWidth, _imageHeight, System.Drawing.Imaging.PixelFormat.Format32bppArgb))
                            {
                                var bmpData = bmp.LockBits(new Rectangle(0, 0, _imageWidth, _imageHeight),
                                    System.Drawing.Imaging.ImageLockMode.WriteOnly, System.Drawing.Imaging.PixelFormat.Format32bppArgb);
                                System.Runtime.InteropServices.Marshal.Copy(collector.FinalPixels, 0, bmpData.Scan0, collector.FinalPixels.Length);
                                bmp.UnlockBits(bmpData);
                                bmp.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
                            }
                            ms.Position = 0;
                            picOriginal.Image = Image.FromStream(ms);
                        }

                        btnSave.Enabled = true; // Разрешаем сохранение
                    }

                    btnProcess.Enabled = true;
                    btnCancel.Enabled = false;
                });
            });
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            _cts?.Cancel();
            txtLog.AppendText("Запрошена отмена...\r\n");
        }

        // Обработчик кнопки "Сохранить результат"
        private async void btnSave_Click(object sender, EventArgs e)
        {
            if (_resultPixels == null) return;

            using var sfd = new SaveFileDialog();
            sfd.Filter = "PNG Image|*.png";

            if (sfd.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    btnSave.Enabled = false;
                    txtLog.AppendText("Сохранение файла...\r\n");

                    // Вызываем наш асинхронный писатель
                    await AsyncImageWriter.WriteAsync(sfd.FileName, _resultPixels, _imageWidth, _imageHeight, CancellationToken.None);

                    txtLog.AppendText("Файл успешно сохранен!\r\n");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка сохранения: " + ex.Message);
                }
                finally
                {
                    btnSave.Enabled = true;
                }
            }
        }
    }
}